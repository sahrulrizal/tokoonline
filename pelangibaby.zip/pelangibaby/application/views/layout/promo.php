<div class="col-md-12" style="overflow: hidden;">
    <div>
       <img class="img-responsive" src="<?= base_url('uploads/promo/'.$l->img);?>" alt="pelangibaby">
    </div>
    <div class="promo-isi">
      <div class="judul">
        <h2><?=$l->judul;?></h2>
      </div>
       <div class="isi">
        <div><?=$l->isi;?></div>
      </div>
    </div>
 </div>
