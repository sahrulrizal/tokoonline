<?php foreach ($l as $key): ?>
	<div class="laman">
	<?php echo $key->isi; ?>
	</div>
<?php endforeach ?>