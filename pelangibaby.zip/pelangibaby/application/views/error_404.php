<!DOCTYPE html>
<html>
<head>
	<title>ERROR : Halaman Tidak Ditemukan</title>
</head>
<body>
<center>
<h1>ERROR : <b style="color:red;">HALAMAN TIDAK DI TEMUKAN</b></h1>
<a href="<?php echo site_url(); ?>" title="Kembali ke pelangibaby.com"><h2>Klik untuk kembali</h2></a>
</center>
</body>
</html>