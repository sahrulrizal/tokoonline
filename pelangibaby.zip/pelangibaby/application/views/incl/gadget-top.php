<?php foreach ($this->mb->gad_tp() as $gadget): ?>	
	<div class="col-md-12">
		<div style="margin-bottom: 20px;">
		<?= $gadget->isi; ?>
		</div>
	</div>
<?php endforeach ?>