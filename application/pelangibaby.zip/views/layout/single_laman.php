<?php foreach ($l as $key): ?>
	<?php echo $key->isi; ?>
<?php endforeach ?>