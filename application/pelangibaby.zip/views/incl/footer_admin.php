<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-ui.js'); ?>"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/dist/js/app.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/dist/js/demo.js'); ?>" type="text/javascript"></script>

</body>
</html>