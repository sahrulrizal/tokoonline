<script src="<?= base_url(); ?>public/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
<!--
<script type="text/javascript" src="<?= base_url();?>public/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>public/js/dataTables.bootstrap.min.js"></script> 
<script type="text/javascript" src="<?= base_url();?>public/js/smooth-scroll.js"></script>
</body>
-->
</html>